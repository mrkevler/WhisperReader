# Zależności zewnętrzne / Third-party components

Whisper Reader jest natywnym programem SwiftUI. PDFKit, Vision, AppKit, AVFoundation i Foundation są składnikami macOS. Silnik AI i środowisko są pobierane osobno do lokalnego folderu danych aplikacji; teksty użytkownika nie są wysyłane do usługi TTS.

| Składnik | Źródło | Licencja |
|---|---|---|
| Supertonic Python SDK 1.3.1 | [PyPI](https://pypi.org/project/supertonic/1.3.1/) · [archiwum źródeł](https://github.com/supertone-oss-archive/supertonic-py) | MIT |
| Supertonic 3 — wagi, konfiguracja i style głosów | [oficjalne archiwum Supertone](https://huggingface.co/supertone-oss-archive/supertonic-3/tree/aafc6e32416a594460b32413efc49d7fe4ce6d46) | BigScience Open RAIL-M; [pełna licencja lokalna](MODEL_LICENSE.md) |
| ONNX Runtime | [Microsoft / ONNX Runtime](https://github.com/microsoft/onnxruntime) | MIT |
| uv | [Astral](https://github.com/astral-sh/uv) | MIT / Apache-2.0 |
| Python | [Python Software Foundation](https://www.python.org/) | Python Software Foundation License |

## Warunki modelu / Model terms

Supertonic 3: Copyright © 2026 Supertone Inc. Aplikacja używa niezmienionych wag z repozytorium `supertone-oss-archive/supertonic-3`, rewizja `aafc6e32416a594460b32413efc49d7fe4ce6d46`, oraz gotowych stylów M2 i F5. Pliki modelu nie są częścią ZIP aplikacji; pobiera się je podczas przygotowania głosu. Odtwarzana mowa jest wytworzona maszynowo, a nie autentyczną wypowiedzią rzeczywistej osoby.

**Używanie modelu podlega §5 i wszystkim ograniczeniom z Załącznika A licencji OpenRAIL-M.** Krótkie warunki: [polski](MODEL_TERMS.pl.md) · [English](MODEL_TERMS.en.md). Pełny, niezmieniony oryginał: [MODEL_LICENSE.md](MODEL_LICENSE.md). Te pliki są dołączone do aplikacji i dostępne offline. Licencja modelu pozostaje odrębna od autorskiej EULA WhisperReader, zgodnie z jej §5.

**Use of the model is subject to section 5 and all restrictions in Attachment A of OpenRAIL-M.** The [English model terms](MODEL_TERMS.en.md) and [complete model license](MODEL_LICENSE.md) are bundled for offline access. They apply to the model separately from the proprietary WhisperReader EULA. Generated speech is machine-generated; it is not an authentic statement by a real person.

Właściciel [repozytorium Supertonic](https://github.com/supertone-oss-archive/supertonic) zarchiwizował je 9 września 2026 r. Źródła i wagi zachowują własne licencje; upstream nie zapewnia dalszego rozwoju ani wsparcia. WhisperReader korzysta z przypiętej wersji lokalnej, bez usług Voice Builder i bez chmurowego generowania mowy.

## Środowisko / Runtime

Pozostałe biblioteki oraz ich informacje licencyjne są instalowane razem z dystrybucjami Pythona. Dotyczy to również zależności pośrednich i dołączanych bibliotek natywnych; licencja SDK nie zastępuje ich licencji. Bezpośrednie wersje znajdują się w `Engine/requirements.txt`, a rewizja modelu w `Engine/reader_engine.py`. Informacje licencyjne zainstalowanych pakietów pozostają w lokalnym środowisku aplikacji.

Other Python packages, transitive dependencies and bundled native libraries retain their own licenses, installed with their distributions. Do not remove their license or attribution files when preparing a distributable runtime. The SDK license does not replace those separate terms.
