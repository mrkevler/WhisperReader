# AI voice terms — Supertonic 3

These terms apply only to the use of the Supertonic 3 model in WhisperReader. They do not change the app's end-user license agreement (EULA), its personal-use conditions or your rights to your own documents and PDFs. Under section 5 of the EULA, the model retains its separate license.

The model by Supertone Inc. is provided under the **BigScience Open RAIL-M License dated August 18, 2022**. By using the model, you agree to comply with that license, including **section 5 and all restrictions in Attachment A**. Those provisions are incorporated into these terms and are binding on use of the model. If you make the model available to other users, you must also require them to comply with section 5.

The restrictions include unlawful activities, harming minors, deliberately harmful false information, harmful disclosure of personal information, harassment and impersonation without consent. They also cover the forms of discrimination, exploitation of vulnerabilities, harmful fully automated decisions, medical advice and results interpretation, and certain justice, law-enforcement, immigration and asylum uses specified in Attachment A. This is a summary; the complete Attachment A applies.

**The speech you hear is machine-generated and is not an authentic statement by a real person.** Attachment A(e) requires an express and intelligible disclosure when generating or disseminating machine-generated content. Keep that disclosure when sharing generated content. You are responsible for generated outputs and their subsequent use under section 6 of the license.

The app uses **unmodified weights** and preset voices M2/F5 downloaded from the official `supertone-oss-archive/supertonic-3` archive, revision `aafc6e32416a594460b32413efc49d7fe4ce6d46`. Speech is generated locally; your text is not sent to a voice service. Recordings may remain in the app's local cache for replay. After stopping playback, you can remove them with **Clear saved audio** in the app menu.

The complete, unmodified original license is bundled with the app and available offline: **[MODEL_LICENSE.md](MODEL_LICENSE.md)**. If this summary differs from the original, the full model license governs. Sources and licenses of other components: [THIRD_PARTY.md](THIRD_PARTY.md).
