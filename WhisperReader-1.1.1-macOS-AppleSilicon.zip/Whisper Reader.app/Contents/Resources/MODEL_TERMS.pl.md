# Warunki korzystania z głosu AI — Supertonic 3

Te warunki dotyczą wyłącznie korzystania z modelu Supertonic 3 w WhisperReader. Nie zmieniają licencji użytkownika aplikacji (EULA), jej zasad osobistego używania ani praw do własnych dokumentów i plików PDF. Zgodnie z §5 EULA model zachowuje odrębną licencję.

Model Supertone Inc. jest udostępniony na **BigScience Open RAIL-M License z 18 sierpnia 2022 r.** Korzystając z modelu, zobowiązujesz się przestrzegać tej licencji, w tym **§5 i wszystkich ograniczeń z Załącznika A (Attachment A)**. Te postanowienia zostają włączone do niniejszych warunków i są wiążące przy korzystaniu z modelu. Jeśli udostępniasz model innym użytkownikom, musisz również wymagać od nich przestrzegania §5.

Ograniczenia obejmują między innymi bezprawne działania, krzywdzenie małoletnich, celowe szkodliwe dezinformowanie, szkodliwe ujawnianie danych osobowych, nękanie i podszywanie się bez zgody. Obejmują też wskazane w Załączniku A formy dyskryminacji, wykorzystywanie podatności osób, szkodliwe w pełni automatyczne decyzje, porady medyczne i interpretowanie wyników oraz określone zastosowania w wymiarze sprawiedliwości, egzekwowaniu prawa, imigracji i azylu. To skrót; obowiązuje pełny Załącznik A.

**Odtwarzana mowa jest wytworzona maszynowo i nie jest autentyczną wypowiedzią rzeczywistej osoby.** Załącznik A(e) wymaga wyraźnego i zrozumiałego oznaczania treści wytworzonych maszynowo przy ich generowaniu lub rozpowszechnianiu. Zachowaj taką informację, gdy udostępniasz wygenerowaną treść. Odpowiadasz za wygenerowane wyniki i ich dalsze wykorzystanie zgodnie z §6 licencji.

Aplikacja korzysta z **niezmienionych wag** i gotowych głosów M2/F5, pobieranych z oficjalnego archiwum `supertone-oss-archive/supertonic-3`, rewizja `aafc6e32416a594460b32413efc49d7fe4ce6d46`. Mowa powstaje lokalnie; teksty nie są wysyłane do usługi głosowej. Nagrania mogą pozostać w lokalnej pamięci aplikacji do ponownego odtworzenia. Po zatrzymaniu odczytu możesz je usunąć przez **Usuń zapisane audio** w menu aplikacji.

Pełny, niezmieniony oryginał licencji jest dołączony do aplikacji i dostępny bez internetu: **[MODEL_LICENSE.md](MODEL_LICENSE.md)**. W razie rozbieżności tego skrótu z oryginałem obowiązuje pełna licencja modelu. Pochodzenie i licencje pozostałych składników: [THIRD_PARTY.md](THIRD_PARTY.md).
