#!/bin/bash
set -euo pipefail

ENGINE_DIR="$(cd "$(dirname "$0")" && pwd)"
READER_HOME="${WHISPER_READER_HOME:-$HOME/Library/Application Support/WhisperReader}"
UV_VERSION="0.12.21"
UV_SHA256="b88bda573e566ef9bced66b155fe0408626fbbc053aee1c30ba686f0728c9447"
PYTHON_VERSION="3.12.12"
STAGING=""
CHILD_PID=""

cleanup() {
    if [[ -n "$CHILD_PID" ]]; then
        kill -TERM "$CHILD_PID" 2>/dev/null || true
        wait "$CHILD_PID" 2>/dev/null || true
    fi
    if [[ -n "$STAGING" && -d "$STAGING" ]]; then
        rm -rf "$STAGING"
    fi
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

# A background child plus wait lets bash handle Quit immediately. Foreground
# commands otherwise delay its signal trap until a multi-GB download finishes.
run() {
    "$@" &
    CHILD_PID=$!
    wait "$CHILD_PID"
    CHILD_PID=""
}

if [[ "$(uname -s)" != "Darwin" || "$(uname -m)" != "arm64" ]]; then
    echo "Głos AI wymaga Maca z procesorem Apple Silicon (M1 lub nowszym)." >&2
    exit 1
fi

mkdir -p "$READER_HOME/tools-v2" "$READER_HOME/python-v2" "$READER_HOME/cache"
rm -f "$READER_HOME/ready-v2.json"
export WHISPER_READER_HOME="$READER_HOME"
export UV_PYTHON_INSTALL_DIR="$READER_HOME/python-v2"
export UV_PYTHON_BIN_DIR="$READER_HOME/tools-v2"
export UV_PYTHON_INSTALL_BIN=0
export UV_CACHE_DIR="$READER_HOME/cache/uv-v2"
export UV_NO_MODIFY_PATH=1
export UV_NO_PROGRESS=1
export UV_NO_CONFIG=1
export PYTHONNOUSERSITE=1
export HF_HUB_DISABLE_TELEMETRY=1
export DO_NOT_TRACK=1
export HF_HUB_DISABLE_XET=1
export PYTHONUNBUFFERED=1

UV="$READER_HOME/tools-v2/uv"
if [[ ! -x "$UV" ]] || [[ "$("$UV" --version)" != "uv $UV_VERSION"* ]]; then
    echo "Przygotowanie lokalnego środowiska…"
    STAGING="$(mktemp -d "$READER_HOME/cache/uv-download.XXXXXX")"
    run /usr/bin/curl --fail --location --retry 3 --connect-timeout 30 \
        "https://github.com/astral-sh/uv/releases/download/$UV_VERSION/uv-aarch64-apple-darwin.tar.gz" \
        --output "$STAGING/uv.tar.gz"
    ACTUAL_SHA256="$(/usr/bin/shasum -a 256 "$STAGING/uv.tar.gz" | /usr/bin/awk '{print $1}')"
    if [[ "$ACTUAL_SHA256" != "$UV_SHA256" ]]; then
        echo "Suma kontrolna środowiska jest niepoprawna. Przerwano przygotowanie." >&2
        exit 1
    fi
    /usr/bin/tar -xzf "$STAGING/uv.tar.gz" -C "$STAGING"
    /bin/cp "$STAGING/uv-aarch64-apple-darwin/uv" "$UV"
    chmod 755 "$UV"
    rm -rf "$STAGING"
    STAGING=""
fi

echo "Przygotowanie Pythona i bibliotek głosu…"
run "$UV" python install "$PYTHON_VERSION" --managed-python
# uv relocates libpython's install name. On macOS its existing linker signature
# can become invalid after that change; repair only this app-owned library.
PYTHON_ROOT="$UV_PYTHON_INSTALL_DIR/cpython-$PYTHON_VERSION-macos-aarch64-none"
PYTHON_LIBRARY="$PYTHON_ROOT/lib/libpython3.12.dylib"
if [[ -f "$PYTHON_LIBRARY" ]] && ! /usr/bin/codesign --verify --strict "$PYTHON_LIBRARY" 2>/dev/null; then
    echo "Kończenie przygotowania biblioteki Pythona dla macOS…"
    /usr/bin/codesign --force --sign - "$PYTHON_LIBRARY"
fi
run "$PYTHON_ROOT/bin/python3.12" --version
if [[ ! -x "$READER_HOME/runtime-v2/bin/python" ]]; then
    run "$UV" venv --managed-python --python "$PYTHON_VERSION" "$READER_HOME/runtime-v2"
fi
run "$UV" pip install --python "$READER_HOME/runtime-v2/bin/python" --requirements "$ENGINE_DIR/requirements.txt"

echo "Pobieranie głosu AI (około 400 MB; pobieranie można wznowić)…"
run "$READER_HOME/runtime-v2/bin/python" "$ENGINE_DIR/reader_engine.py" --download
run "$READER_HOME/runtime-v2/bin/python" "$ENGINE_DIR/reader_engine.py" --check
"$READER_HOME/runtime-v2/bin/python" - "$READER_HOME" "$ENGINE_DIR" <<'PY'
import json, os, pathlib, sys, time
sys.path.insert(0, sys.argv[2])
from reader_engine import ENGINE_VERSION, MODEL_REPO, MODEL_REVISION
home = pathlib.Path(sys.argv[1])
temporary = home / "ready-v2.json.tmp"
temporary.write_text(json.dumps({"engine_version": ENGINE_VERSION, "model_repo": MODEL_REPO, "model_revision": MODEL_REVISION, "prepared_at": time.time()}))
os.replace(temporary, home / "ready-v2.json")
PY
echo "Gotowe. Od teraz odczyt działa lokalnie, bez internetu."
