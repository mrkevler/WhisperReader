#!/usr/bin/env python3
"""Serial, offline Supertonic worker. stdout is reserved for NDJSON.

Only --download accesses the network. Version 2 stores its model and runtime
separately from the original Chatterbox installation.
"""

from __future__ import annotations

import argparse
import contextlib
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import time
import traceback
import unicodedata
import wave

MODEL_REPO = "supertone-oss-archive/supertonic-3"
MODEL_REVISION = "aafc6e32416a594460b32413efc49d7fe4ce6d46"
ENGINE_VERSION = 2
SAMPLE_RATE = 44100
VOICES = tuple(f"{gender}{number}" for gender in ("M", "F") for number in range(1, 6))
MAX_TEXT_LENGTH = 1000
MAX_CHUNK_LENGTH = 360
MAX_LINE_LENGTH = 65536
SILENCE_SECONDS = 0.15
MODEL_FILES = (
    "onnx/duration_predictor.onnx", "onnx/text_encoder.onnx",
    "onnx/vector_estimator.onnx", "onnx/vocoder.onnx",
    "onnx/tts.json", "onnx/unicode_indexer.json",
    "config.json", "LICENSE", "README.md",
) + tuple(f"voice_styles/{voice}.json" for voice in VOICES)


def application_home() -> Path:
    value = os.environ.get("WHISPER_READER_HOME")
    return Path(value).expanduser().resolve() if value else (
        Path.home() / "Library" / "Application Support" / "WhisperReader"
    )


def model_directory(home: Path) -> Path:
    return home / "models" / "supertonic-3" / MODEL_REVISION


def configure_environment(home: Path, *, offline: bool = True) -> None:
    # Set these before importing the SDK, ONNX Runtime or Hugging Face.
    os.environ["HF_HOME"] = str(home / "huggingface-v2")
    os.environ["HF_HUB_CACHE"] = str(home / "huggingface-v2" / "hub")
    os.environ["HF_HUB_OFFLINE"] = "1" if offline else "0"
    os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
    os.environ["HF_HUB_DISABLE_XET"] = "1"
    os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1" if offline else "0"
    os.environ["DO_NOT_TRACK"] = "1"
    os.environ["SUPERTONIC_CACHE_DIR"] = str(model_directory(home))
    os.environ["SUPERTONIC_INTRA_OP_THREADS"] = "2"
    os.environ["SUPERTONIC_INTER_OP_THREADS"] = "1"
    os.environ["OMP_NUM_THREADS"] = "2"
    os.environ["OPENBLAS_NUM_THREADS"] = "2"
    os.environ["VECLIB_MAXIMUM_THREADS"] = "2"


def validate_installation(home: Path) -> Path:
    directory = model_directory(home)
    if any(not (directory / name).is_file() or (directory / name).stat().st_size == 0 for name in MODEL_FILES):
        raise RuntimeError("Brakuje plików głosu AI. Uruchom przygotowanie głosu w aplikacji.")
    return directory


class Backend:
    def __init__(self, tts):
        self.tts = tts
        if tts.sample_rate != SAMPLE_RATE:
            raise RuntimeError("Niezgodna częstotliwość fragmentów dźwięku.")
        # Keep only the two most recently selected presets; model weights are
        # shared. The UI chooses two of the ten bundled, explicitly allowed IDs.
        self.styles = {}
        self.voice_style("M1")
        self.voice_style("F1")

    def voice_style(self, voice: str):
        if voice not in VOICES:
            raise ValueError("Nieprawidłowy głos AI.")
        if voice in self.styles:
            style = self.styles.pop(voice)
        else:
            style = self.tts.get_voice_style(voice_name=voice)
        self.styles[voice] = style
        if len(self.styles) > 2:
            del self.styles[next(iter(self.styles))]
        return style


def load_backend(home: Path) -> Backend:
    configure_environment(home)
    directory = validate_installation(home)
    # Missing files fail above, before any optional runtime import or download.
    from supertonic import TTS

    return Backend(TTS(model="supertonic-3", model_dir=directory, auto_download=False,
                       intra_op_num_threads=2, inter_op_num_threads=1))


def download_models(home: Path) -> None:
    configure_environment(home, offline=False)
    from huggingface_hub import snapshot_download

    directory = model_directory(home)
    print(f"Pobieranie: {MODEL_REPO}", flush=True)
    downloaded = Path(snapshot_download(
        repo_id=MODEL_REPO, revision=MODEL_REVISION, local_dir=str(directory),
        allow_patterns=list(MODEL_FILES), max_workers=2,
    ))
    if downloaded.resolve() != directory.resolve():
        raise RuntimeError("Pobrany model ma nieoczekiwaną wersję.")
    validate_installation(home)
    print("Pliki głosu są pobrane. Sprawdzanie działania bez internetu…", flush=True)


_QUOTES = str.maketrans({
    "„": '"', "“": '"', "”": '"', "‟": '"', "«": '"', "»": '"',
    "‚": "'", "‘": "'", "’": "'", "‹": "'", "›": "'",
})
_DECORATIONS = re.compile(
    "[\U0001f1e6-\U0001f1ff\U0001f300-\U0001faff\u2600-\u27bf"
    "\u231a\u231b\u23e9-\u23fa♥♡☆★]+"
)
_INVISIBLE_FORMATTING = re.compile("[\ufe0e\ufe0f\u200d\ufeff\u00ad]")
_FRACTION = re.compile(r"(?<![\w./\\])([+-]?\d+)\s*/\s*(\d+)(?![\w/\\]|\.\d)")
_SPOKEN_SYMBOLS = {
    "pl": {
        "≤": "mniejsze lub równe", "≥": "większe lub równe", "≠": "różne od",
        "≈": "w przybliżeniu równe", "±": "plus minus", "×": "razy", "÷": "dzielone przez",
        "➕": "plus", "➖": "minus", "➗": "dzielone przez", "✖": "razy", "✕": "razy",
        "→": "strzałka w prawo", "←": "strzałka w lewo",
        "/": "ukośnik", "\\": "ukośnik odwrotny", "_": "podkreślenie",
        "#": "krzyżyk", "[": "nawias kwadratowy otwierający", "]": "nawias kwadratowy zamykający",
        "|": "pionowa kreska", "`": "odwrócony apostrof", "@": "małpa", "©": "prawa autorskie",
    },
    "en": {
        "≤": "less than or equal to", "≥": "greater than or equal to", "≠": "not equal to",
        "≈": "approximately equal to", "±": "plus or minus", "×": "times", "÷": "divided by",
        "➕": "plus", "➖": "minus", "➗": "divided by", "✖": "times", "✕": "times",
        "→": "right arrow", "←": "left arrow",
        "/": "slash", "\\": "backslash", "_": "underscore",
        "#": "hash", "[": "opening square bracket", "]": "closing square bracket",
        "|": "vertical bar", "`": "backtick", "@": "at", "©": "copyright",
    },
}


def normalize_text(text: str, language: str = "pl") -> str:
    """Make known SDK-unsafe characters speakable without dropping their meaning.

    The SDK removes slashes and code delimiters and rejects some ordinary Polish
    typography. Keep letters/numbers in order, verbalize meaningful symbols and
    remove only known decorative/formatting characters. Unknown symbols remain
    for explicit validation against the actual model's character index.
    """
    text = unicodedata.normalize("NFC", text).translate(_QUOTES)
    text = _INVISIBLE_FORMATTING.sub("", text).replace("⁄", "/")
    divided_by = "dzielone przez" if language == "pl" else "divided by"

    def fraction(match: re.Match) -> str:
        # A slash-separated date or path is not a single fraction, even when
        # spaces surround its separators. Preserve each separator by name below.
        before = text[:match.start()].rstrip()
        after = text[match.end():].lstrip()
        if (before and before[-1] in "/\\") or (after and after[0] in "/\\"):
            return match.group(0)
        return f"{match.group(1)} {divided_by} {match.group(2)}"

    text = _FRACTION.sub(fraction, text)
    symbols = _SPOKEN_SYMBOLS[language]
    # Expand meaningful operators before removing emoji ranges: for example ✖
    # is also a dingbat, but it must not disappear from a mathematical formula.
    text = "".join(f" {symbols[char]} " if char in symbols else char for char in text)
    text = _DECORATIONS.sub(" ", text)
    return re.sub(r"\s+", " ", text).strip()


def validate_speech_text(backend: Backend, text: str) -> None:
    valid, unsupported = backend.tts.model.text_processor.validate_text(text)
    if not valid:
        characters = sorted(set(unsupported))
        details = ", ".join(f"{char!r} (U+{ord(char):04X})" for char in characters[:8])
        if len(characters) > 8:
            details += ", …"
        raise ValueError("Tekst zawiera znaki nieobsługiwane przez głos AI: " + details)


def validate_request(request: object) -> dict:
    if not isinstance(request, dict):
        raise ValueError("Polecenie musi być obiektem JSON.")
    identifier = request.get("id")
    if not isinstance(identifier, (str, int)) or isinstance(identifier, bool):
        raise ValueError("Brakuje identyfikatora polecenia.")
    if isinstance(identifier, str) and len(identifier) > 256:
        raise ValueError("Identyfikator polecenia jest za długi.")
    if request.get("command") != "synthesize":
        raise ValueError("Nieznane polecenie.")
    text = request.get("text")
    if not isinstance(text, str) or not text.strip():
        raise ValueError("Brak tekstu do przeczytania.")
    if len(text) > MAX_TEXT_LENGTH:
        raise ValueError("Fragment tekstu jest za długi. Podziel go na krótsze fragmenty.")
    if any(unicodedata.category(char) in ("Cc", "Cs") and not char.isspace() for char in text):
        raise ValueError("Tekst zawiera nieprawidłowe znaki sterujące.")
    if request.get("language") not in ("pl", "en"):
        raise ValueError("Wybierz język polski lub angielski.")
    voice = request.get("voice", "M1")
    if voice == "default":
        voice = "M1"
    if voice not in VOICES:
        raise ValueError("Nieprawidłowy głos AI.")
    output = request.get("output")
    if not isinstance(output, str) or "\x00" in output or not Path(output).is_absolute() or Path(output).suffix.lower() != ".wav":
        raise ValueError("Nieprawidłowa ścieżka pliku dźwiękowego.")
    normalized = normalize_text(text, request["language"])
    if not normalized:
        raise ValueError("Brak tekstu do przeczytania.")
    return {**request, "text": normalized, "voice": voice}


def split_text(text: str, max_length: int = MAX_CHUNK_LENGTH) -> list[str]:
    """Bound every pass, retaining every character in the original order.

    SDK 1.3.1 keeps an oversized sentence intact even when max_chunk_length is
    supplied. Pre-split here at sentences/words, with a hard fallback only for
    unusually long unbroken tokens. Callers strip boundary whitespace for TTS.
    """
    if max_length < 2:
        raise ValueError("Fragment musi mieć co najmniej dwa znaki.")
    chunks = []
    while len(text) > max_length:
        window = text[:max_length]
        sentences = [match.end() for match in re.finditer(r"(?<=[.!?;:])\s+", window)
                     if match.end() >= max_length // 2]
        words = [match.end() for match in re.finditer(r"\s+", window)]
        boundary = sentences[-1] if sentences else (words[-1] if words else max_length)
        chunks.append(text[:boundary])
        text = text[boundary:]
    if text:
        chunks.append(text)
    return chunks


def write_wave_atomic(output: Path, pcm_bytes: bytes, sample_rate: int) -> None:
    if not pcm_bytes or len(pcm_bytes) % 2 or sample_rate != SAMPLE_RATE:
        raise ValueError("Silnik nie wygenerował prawidłowego dźwięku.")
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=output.parent, prefix=".speech-", suffix=".wav", delete=False) as handle:
            temporary = Path(handle.name)
        with wave.open(str(temporary), "wb") as handle:
            handle.setnchannels(1)
            handle.setsampwidth(2)
            handle.setframerate(sample_rate)
            handle.writeframes(pcm_bytes)
        os.replace(temporary, output)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def synthesize(backend: Backend, request: dict) -> dict:
    import numpy as np

    validate_speech_text(backend, request["text"])
    started = time.monotonic()
    segments = []
    style = backend.voice_style(request["voice"])
    for chunk in split_text(request["text"]):
        if not chunk.strip():
            continue
        wav, _duration = backend.tts.synthesize(
            text=chunk.strip(), lang=request["language"], voice_style=style,
            total_steps=16 if request["voice"] == "F5" else 8,
            speed=1.0, max_chunk_length=MAX_CHUNK_LENGTH,
            silence_duration=SILENCE_SECONDS, verbose=False,
        )
        audio = np.asarray(wav, dtype=np.float32)
        if audio.ndim == 2 and audio.shape[0] == 1:
            audio = audio[0]
        if audio.ndim != 1 or not audio.size or not np.isfinite(audio).all():
            raise RuntimeError("Silnik wygenerował nieprawidłowy dźwięk. Spróbuj ponownie.")
        if float(np.max(np.abs(audio))) < 0.0001:
            raise RuntimeError("Silnik wygenerował ciszę. Spróbuj ponownie.")
        if segments:
            segments.append(np.zeros(round(SILENCE_SECONDS * SAMPLE_RATE), dtype=np.float32))
        segments.append(audio)
    if not segments:
        raise RuntimeError("Silnik nie wygenerował dźwięku. Spróbuj ponownie.")
    audio = np.concatenate(segments)
    pcm = (np.clip(audio, -1, 1) * 32767).astype("<i2").tobytes()
    output = Path(request["output"])
    write_wave_atomic(output, pcm, SAMPLE_RATE)
    elapsed = time.monotonic() - started
    duration = len(audio) / SAMPLE_RATE
    print(f"Generated {duration:.2f}s in {elapsed:.2f}s", file=sys.stderr, flush=True)
    return {"id": request["id"], "event": "audio", "path": str(output),
            "sample_rate": SAMPLE_RATE, "duration": duration, "gen_elapsed": elapsed,
            "voice": request["voice"]}


def serve(backend, input_stream, emit, synthesizer=synthesize) -> None:
    while True:
        line = input_stream.readline(MAX_LINE_LENGTH + 1)
        if not line:
            return
        request_id = None
        try:
            if len(line) > MAX_LINE_LENGTH:
                while line and not line.endswith("\n"):
                    line = input_stream.readline(MAX_LINE_LENGTH + 1)
                raise ValueError("Polecenie jest za długie.")
            if not line.strip():
                continue
            request = json.loads(line)
            if isinstance(request, dict) and isinstance(request.get("id"), (str, int)) and not isinstance(request["id"], bool):
                request_id = request["id"]
            request = validate_request(request)
            with contextlib.redirect_stdout(sys.stderr):
                response = synthesizer(backend, request)
            emit(response)
        except BrokenPipeError:
            raise
        except Exception as error:
            traceback.print_exc(file=sys.stderr)
            emit({"id": request_id, "event": "error", "message": str(error)})


def main() -> int:
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--download", action="store_true")
    mode.add_argument("--check", action="store_true")
    args = parser.parse_args()
    home = application_home()
    if args.download:
        download_models(home)
        return 0
    if args.check:
        load_backend(home)
        print("Głos AI jest gotowy do pracy lokalnej.", flush=True)
        return 0

    # Native libraries must not corrupt the protocol, including during imports.
    protocol = os.fdopen(os.dup(sys.stdout.fileno()), "w", buffering=1, encoding="utf-8")
    os.dup2(sys.stderr.fileno(), sys.stdout.fileno())
    sys.stdout = sys.stderr

    def emit(event: dict) -> None:
        protocol.write(json.dumps(event, ensure_ascii=False, allow_nan=False) + "\n")
        protocol.flush()

    try:
        emit({"event": "status", "message": "Ładowanie lokalnego głosu AI…"})
        backend = load_backend(home)
        emit({"event": "ready", "engine_version": ENGINE_VERSION, "voices": list(VOICES)})
        serve(backend, sys.stdin, emit)
        return 0
    except BrokenPipeError:
        return 0
    except Exception as error:
        traceback.print_exc(file=sys.stderr)
        emit({"event": "error", "message": str(error)})
        return 1
    finally:
        protocol.close()


if __name__ == "__main__":
    raise SystemExit(main())
